package logicadevista;

public class Vista {

}
